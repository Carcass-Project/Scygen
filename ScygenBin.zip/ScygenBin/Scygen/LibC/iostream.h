#pragma once
#include <stdint.h>

int printf(const char* str, ...);
