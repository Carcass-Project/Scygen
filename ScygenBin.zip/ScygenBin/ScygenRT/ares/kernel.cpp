/* 
	This is your starter kernel!
	You can explore more of the Scygen functions given to you, and build a bigger and better kernel!
	Have fun!
*/

#include <Scygen/libc/iostream> // Scygen basic I/O header file.

// Needed, so that the kernel can compile.
int main() { kmain(); }

// Your kernel's entry point.
void kmain() {
	kprintf("Hello, kernel!");
}